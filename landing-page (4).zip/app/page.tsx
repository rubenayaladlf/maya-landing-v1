"use client"

import App from "../src/pages/_app"

export default function SyntheticV0PageForDeployment() {
  return <App />
}